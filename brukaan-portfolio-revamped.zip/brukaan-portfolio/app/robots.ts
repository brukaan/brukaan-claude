import type { MetadataRoute } from 'next'
export default function robots(): MetadataRoute.Robots {
  const base = process.env.BETTER_AUTH_URL || 'https://brukaandesigns.com'
  return { rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/api/', '/sign-in', '/sign-up'] }], sitemap: `${base}/sitemap.xml` }
}
