import { ArrowUpRight } from 'lucide-react'
import { getGallery, getProjects, getServices, getSettings, youtubeEmbed } from '@/lib/data'
import { galleryCategories } from '@/lib/gallery-seed'
import { SiteHeader } from '@/components/site/header'
import { Hero } from '@/components/site/hero'
import { Gallery } from '@/components/site/gallery'
import { ContactForm } from '@/components/site/contact-form'
import { SiteFooter } from '@/components/site/footer'
import { WhatsAppFloat } from '@/components/site/whatsapp-float'
import { RevealObserver } from '@/components/site/reveal'

export const revalidate = 60

const STEPS = [
  ['Consultation', 'We listen first — to your family, your business, your aspirations and your budget.'],
  ['Site & context', 'Climate, orientation, neighbours and regulations shape the brief before a line is drawn.'],
  ['Concept design', 'Massing, plans and mood studies that translate the brief into a clear design idea.'],
  ['Design development', 'Materials, joinery, lighting and services are resolved in detail and visualised in 3D.'],
  ['Documentation', 'Coordinated working drawings and specifications that contractors can build from.'],
  ['Execution', 'Site coordination and quality control, keeping budget and programme on track.'],
]
const HERO = ['/gallery/exteriors-11.jpg', '/gallery/exteriors-08.jpg', '/gallery/landscape-01.jpg', '/gallery/exteriors-14.jpg']

export default async function Page() {
  const [s, gallery, services, projects] = await Promise.all([getSettings(), getGallery(), getServices(), getProjects()])
  const offices = s.address.split(' · ').map((a) => a.trim()).filter(Boolean)
  const video = youtubeEmbed(s.studioVideoUrl)
  const heroSlides = HERO.filter((h) => gallery.some((g) => g.url === h)).length ? HERO : gallery.slice(0, 4).map((g) => g.url)

  const ld = {
    '@context': 'https://schema.org', '@type': 'ProfessionalService', name: s.firmName, description: s.description,
    url: 'https://brukaandesigns.com', telephone: s.phone, email: s.email, image: 'https://brukaandesigns.com/gallery/exteriors-11.jpg',
    address: { '@type': 'PostalAddress', addressLocality: 'Bhubaneswar', addressRegion: 'Odisha', addressCountry: 'IN' },
    areaServed: ['Bhubaneswar', 'Navi Mumbai'], sameAs: Object.values(s.social).filter(Boolean),
  }

  return (
    <main>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <RevealObserver />
      <SiteHeader firmName={s.firmName} logoUrl={s.logoUrl} />
      <Hero slides={heroSlides} tagline={s.tagline} offices={s.serviceAreas || 'Bhubaneswar · Navi Mumbai'} />

      <section id="studio" className="studio pad">
        <div className="container">
          <div className="studio-grid">
            <div data-reveal>
              <p className="label">01 — The studio</p>
              <h2>Luxury is a <em>way of living.</em></h2>
              <p className="lead" style={{ maxWidth: 760 }}>{s.description}</p>
              <div className="stats">
                <div><strong>{services.length}</strong><span>Disciplines</span></div>
                <div><strong>{offices.length || 2}</strong><span>Studios</span></div>
                <div><strong>{gallery.length}</strong><span>Images in portfolio</span></div>
              </div>
            </div>
            <aside className="studio-side" data-reveal>
              <div><h4>Disciplines</h4><ul>{services.map((x) => <li key={x.slug}>{x.title}</li>)}</ul></div>
              <div><h4>Studios</h4>{offices.map((o) => <p key={o} style={{ marginBottom: 12 }}>{o}</p>)}</div>
              <a className="link" href="#contact" style={{ justifySelf: 'start' }}>Start a conversation <ArrowUpRight size={14} /></a>
            </aside>
          </div>
        </div>
      </section>

      <section id="portfolio" className="pad dark">
        <div className="container">
          <div className="section-head" data-reveal>
            <div><p className="label">02 — Portfolio</p><h2>Selected <em>work</em></h2></div>
            <p>Residences, interiors and landscapes — rendered from concept to completion.</p>
          </div>
          <Gallery items={gallery} categories={galleryCategories} limit={12} showAllLink />
        </div>
      </section>

      <section id="services" className="services pad">
        <div className="container">
          <div className="section-head" data-reveal><div><p className="label">03 — Services</p><h2>What we <em>design</em></h2></div></div>
          <div className="service-list" data-reveal>
            {services.map((x, i) => (
              <details className="service" key={x.slug} open={i === 0}>
                <summary><span className="num">0{i + 1}</span><h3>{x.title}</h3><span className="sum">{x.summary}</span><span className="plus" aria-hidden="true" /></summary>
                <div className="body"><p>{x.details}</p></div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {projects.length > 0 && (
        <section id="projects" className="pad dark">
          <div className="container">
            <div className="section-head" data-reveal><div><p className="label">04 — Commissions</p><h2>Projects <em>index</em></h2></div><p>Residential, hospitality, retail and civic commissions across Odisha.</p></div>
            <div data-reveal>
              {projects.map((p, i) => (
                <a key={p.slug} href={`/projects/${p.slug}`} className="proj-row">
                  <span className="num">{String(i + 1).padStart(2, '0')}</span>
                  <h3>{p.title}</h3>
                  <span className="t">{p.type}</span>
                  <span className="t">{[p.location, p.year].filter(Boolean).join(' · ')}</span>
                  <ArrowUpRight size={20} />
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      <section id="approach" className="pad">
        <div className="container">
          <div className="section-head" data-reveal><div><p className="label">05 — Approach</p><h2>Designed for <em>distinction</em></h2></div><p>A collaborative, rigorous process shaped around the context of every project.</p></div>
          <div className="steps" data-reveal>
            {STEPS.map(([t, d], i) => <div className="step" key={t}><b>0{i + 1}</b><h4>{t}</h4><p>{d}</p></div>)}
          </div>
        </div>
      </section>

      {video && (
        <section id="film" className="pad dark">
          <div className="container">
            <div className="section-head" data-reveal><div><p className="label">06 — Film</p><h2>Studio <em>in motion</em></h2></div><p>Walkthroughs and presentations from the studio.</p></div>
            <div className="video-frame" data-reveal><iframe src={video} title="Brukaan studio film" loading="lazy" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" allowFullScreen /></div>
          </div>
        </section>
      )}

      <section id="contact" className="pad">
        <div className="container">
          <div className="contact-grid">
            <div data-reveal>
              <p className="label">07 — Contact</p>
              <h2>Let&apos;s discuss your <em>project.</em></h2>
              <div className="contact-info">
                {s.phone && <div><h4>Call</h4><a href={`tel:${s.phone}`}>{s.phone}</a></div>}
                {s.email && <div><h4>Email</h4><a href={`mailto:${s.email}`}>{s.email}</a></div>}
                {offices.map((o, i) => <div key={o}><h4>{i === 0 ? 'Studios' : '\u00a0'}</h4><p>{o}</p></div>)}
                {s.businessHours && <div><h4>Hours</h4><p>{s.businessHours}</p></div>}
                <div className="socials">
                  {s.whatsapp && <a href={`https://wa.me/${s.whatsapp}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>}
                  {Object.entries(s.social).filter(([, v]) => v).map(([k, v]) => <a key={k} href={v} target="_blank" rel="noopener noreferrer">{k}</a>)}
                  {s.mapsDirectionsUrl && <a href={s.mapsDirectionsUrl} target="_blank" rel="noopener noreferrer">Directions</a>}
                </div>
              </div>
            </div>
            <div data-reveal><ContactForm whatsapp={s.whatsapp} /></div>
          </div>
          {s.mapsEmbedUrl && <iframe className="map" src={s.mapsEmbedUrl} title="Studio location" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />}
        </div>
      </section>

      <SiteFooter s={s} />
      <WhatsAppFloat number={s.whatsapp} />
    </main>
  )
}
