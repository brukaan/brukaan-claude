import { NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { inquiries } from '@/lib/db/schema'
import { notifyStudio } from '@/lib/notify'

export const dynamic = 'force-dynamic'

const opt = (max: number) => z.string().trim().max(max).optional().transform((v) => v || undefined)
const inquirySchema = z.object({
  name: z.string().trim().min(2, 'Please enter your name').max(120),
  email: z.string().trim().email('Please enter a valid email').max(200),
  phone: opt(40), projectType: opt(80), location: opt(160), sizeOrBudget: opt(160),
  message: z.string().trim().min(10, 'Please tell us a little more about your project').max(4000),
  website: z.string().optional(), // honeypot — real users leave this empty
})

// Tiny per-instance rate limiter (5 enquiries / 10 min / IP). Enough to blunt casual spam.
const hits = new Map<string, number[]>()
function limited(ip: string) {
  const now = Date.now(), recent = (hits.get(ip) ?? []).filter((t) => now - t < 600_000)
  recent.push(now); hits.set(ip, recent)
  if (hits.size > 5000) hits.clear()
  return recent.length > 5
}

export async function POST(request: Request) {
  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown'
  if (limited(ip)) return NextResponse.json({ ok: false, error: 'Too many requests. Please try again later.' }, { status: 429 })
  try {
    const parsed = inquirySchema.safeParse(await request.json())
    if (!parsed.success) {
      const errors = Object.fromEntries(parsed.error.issues.map((i) => [String(i.path[0]), i.message]))
      return NextResponse.json({ ok: false, errors }, { status: 400 })
    }
    const { website, ...data } = parsed.data
    if (website) return NextResponse.json({ ok: true }, { status: 201 }) // bot: pretend success, store nothing
    const [row] = await db.insert(inquiries).values(data).returning({ id: inquiries.id })
    await notifyStudio(data)
    return NextResponse.json({ ok: true, id: row.id }, { status: 201 })
  } catch (error) {
    console.error('[inquiries]', (error as Error).message)
    return NextResponse.json({ ok: false, error: 'Unable to submit your enquiry right now.' }, { status: 500 })
  }
}
