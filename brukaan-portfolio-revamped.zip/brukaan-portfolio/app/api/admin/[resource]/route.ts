import { NextResponse } from 'next/server'
import { asc, desc } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db'
import { denyUnlessAdmin } from '@/lib/admin-auth'
import { buildPayload, isResource, tables } from '@/lib/admin-api'
import { resources } from '@/lib/admin-resources'

export const dynamic = 'force-dynamic'

export async function GET(_req: Request, ctx: { params: Promise<{ resource: string }> }) {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  const { resource } = await ctx.params
  if (!isResource(resource)) return NextResponse.json({ ok: false, error: 'Unknown resource' }, { status: 404 })
  const t = tables[resource] as any
  const order: any[] = resource === 'inquiries' ? [desc(t.createdAt)] : resource === 'media' ? [asc(t.sortOrder), desc(t.id)] : [asc(t.sortOrder), asc(t.id)]
  const rows = await db.select().from(t).orderBy(...order)
  return NextResponse.json({ ok: true, rows })
}

export async function POST(req: Request, ctx: { params: Promise<{ resource: string }> }) {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  const { resource } = await ctx.params
  if (!isResource(resource) || !resources[resource].canCreate) return NextResponse.json({ ok: false, error: 'Not allowed' }, { status: 404 })
  const body = await req.json().catch(() => null)
  if (!body || typeof body !== 'object') return NextResponse.json({ ok: false, error: 'Invalid body' }, { status: 400 })
  const { data, errors } = buildPayload(resource, body, 'create')
  if (errors.length) return NextResponse.json({ ok: false, error: errors.join('. ') }, { status: 400 })
  try {
    const inserted: any[] = await (db.insert(tables[resource] as any).values(data) as any).returning()
    const row = inserted[0]
    revalidatePath('/', 'layout')
    return NextResponse.json({ ok: true, row }, { status: 201 })
  } catch (e: any) {
    const dup = (e?.code ?? e?.cause?.code) === '23505'
    return NextResponse.json({ ok: false, error: dup ? 'That URL slug is already used. Choose another.' : 'Could not save.' }, { status: dup ? 409 : 500 })
  }
}
