import { NextResponse } from 'next/server'
import { eq } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db'
import { denyUnlessAdmin } from '@/lib/admin-auth'
import { buildPayload, isResource, tables } from '@/lib/admin-api'
import { resources } from '@/lib/admin-resources'

export const dynamic = 'force-dynamic'
type Ctx = { params: Promise<{ resource: string; id: string }> }

export async function PATCH(req: Request, ctx: Ctx) {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  const { resource, id } = await ctx.params
  const numId = Number(id)
  if (!isResource(resource) || !Number.isInteger(numId)) return NextResponse.json({ ok: false, error: 'Not found' }, { status: 404 })
  const body = await req.json().catch(() => null)
  if (!body || typeof body !== 'object') return NextResponse.json({ ok: false, error: 'Invalid body' }, { status: 400 })
  const { data, errors } = buildPayload(resource, body, 'update')
  if (errors.length) return NextResponse.json({ ok: false, error: errors.join('. ') }, { status: 400 })
  if (!Object.keys(data).length) return NextResponse.json({ ok: false, error: 'Nothing to update' }, { status: 400 })
  const t = tables[resource] as any
  try {
    const [row] = await db.update(t).set('updatedAt' in t ? { ...data, updatedAt: new Date() } : data).where(eq(t.id, numId)).returning()
    if (!row) return NextResponse.json({ ok: false, error: 'Not found' }, { status: 404 })
    revalidatePath('/', 'layout')
    return NextResponse.json({ ok: true, row })
  } catch (e: any) {
    const dup = (e?.code ?? e?.cause?.code) === '23505'
    return NextResponse.json({ ok: false, error: dup ? 'That URL slug is already used.' : 'Could not save.' }, { status: dup ? 409 : 500 })
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  const { resource, id } = await ctx.params
  const numId = Number(id)
  if (!isResource(resource) || !resources[resource].canDelete || !Number.isInteger(numId)) return NextResponse.json({ ok: false, error: 'Not found' }, { status: 404 })
  const t = tables[resource] as any
  await db.delete(t).where(eq(t.id, numId))
  revalidatePath('/', 'layout')
  return NextResponse.json({ ok: true })
}
