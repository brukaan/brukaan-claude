import { NextResponse } from 'next/server'
import { eq } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db'
import { firmSettings } from '@/lib/db/schema'
import { denyUnlessAdmin } from '@/lib/admin-auth'
import { getSettings } from '@/lib/data'
import { settingsFields } from '@/lib/admin-resources'

export const dynamic = 'force-dynamic'
const SOCIAL = ['instagram', 'facebook', 'linkedin', 'youtube', 'pinterest'] as const

export async function GET() {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  const st = await getSettings()
  const { social, ...rest } = st
  return NextResponse.json({ ok: true, settings: { ...rest, ...social } })
}

export async function PUT(req: Request) {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  const body = await req.json().catch(() => null)
  if (!body || typeof body !== 'object') return NextResponse.json({ ok: false, error: 'Invalid body' }, { status: 400 })
  const v: Record<string, string> = {}
  for (const f of settingsFields) v[f.name] = typeof body[f.name] === 'string' ? body[f.name].trim().slice(0, 4000) : ''
  if (!v.firmName) return NextResponse.json({ ok: false, error: 'Firm name is required' }, { status: 400 })
  if (v.whatsapp) v.whatsapp = v.whatsapp.replace(/\D/g, '')
  const social = Object.fromEntries(SOCIAL.map((k) => [k, v[k]]))
  const row = {
    firmName: v.firmName, tagline: v.tagline, description: v.description, address: v.address, city: v.city, state: v.state,
    country: v.country, phone: v.phone, email: v.email, whatsapp: v.whatsapp, mapsEmbedUrl: v.mapsEmbedUrl,
    mapsDirectionsUrl: v.mapsDirectionsUrl, businessHours: v.businessHours, serviceAreas: v.serviceAreas,
    studioVideoUrl: v.studioVideoUrl, socialLinks: social, updatedAt: new Date(),
  }
  const [existing] = await db.select({ id: firmSettings.id }).from(firmSettings).where(eq(firmSettings.id, 'main'))
  if (existing) await db.update(firmSettings).set(row).where(eq(firmSettings.id, 'main'))
  else await db.insert(firmSettings).values({ id: 'main', logoUrl: '/logo.png', ...row })
  revalidatePath('/', 'layout')
  return NextResponse.json({ ok: true })
}
