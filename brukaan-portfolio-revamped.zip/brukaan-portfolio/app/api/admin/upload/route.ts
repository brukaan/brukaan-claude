import { NextResponse } from 'next/server'
import { put } from '@vercel/blob'
import { denyUnlessAdmin } from '@/lib/admin-auth'

export const dynamic = 'force-dynamic'
const MAX = 4 * 1024 * 1024 // Vercel functions accept ~4.5 MB request bodies; the admin UI compresses before upload.

export async function POST(req: Request) {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  if (!process.env.BLOB_READ_WRITE_TOKEN) {
    return NextResponse.json({ ok: false, error: 'Image uploads are not configured yet. Add BLOB_READ_WRITE_TOKEN (Vercel Blob) or paste an image URL instead.' }, { status: 501 })
  }
  const form = await req.formData().catch(() => null)
  const file = form?.get('file')
  if (!(file instanceof File)) return NextResponse.json({ ok: false, error: 'No file received' }, { status: 400 })
  if (!/^image\/(jpeg|png|webp|avif)$/.test(file.type)) return NextResponse.json({ ok: false, error: 'Only JPG, PNG, WebP or AVIF images are allowed' }, { status: 400 })
  if (file.size > MAX) return NextResponse.json({ ok: false, error: 'Image is too large (max 4 MB)' }, { status: 413 })
  const safe = file.name.toLowerCase().replace(/[^a-z0-9._-]+/g, '-').slice(-60)
  try {
    const blob = await put(`gallery/${safe}`, file, { access: 'public', addRandomSuffix: true, contentType: file.type })
    return NextResponse.json({ ok: true, url: blob.url })
  } catch (e) {
    console.error('[upload]', (e as Error).message)
    return NextResponse.json({ ok: false, error: 'Upload failed. Check the Blob token.' }, { status: 500 })
  }
}
