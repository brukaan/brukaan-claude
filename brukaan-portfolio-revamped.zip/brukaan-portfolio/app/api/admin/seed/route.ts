import { NextResponse } from 'next/server'
import { count } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db'
import { firmSettings, media, projects, services } from '@/lib/db/schema'
import { denyUnlessAdmin } from '@/lib/admin-auth'
import { siteConfig } from '@/lib/site-config'
import { gallerySeed } from '@/lib/gallery-seed'
import { STUDIO_VIDEO_DEFAULT, clean } from '@/lib/data'

export const dynamic = 'force-dynamic'

/** Imports the default content into empty tables only — never overwrites existing data. */
export async function POST() {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  const c = siteConfig
  const done: string[] = []
  const n = async (t: any) => (await db.select({ n: count() }).from(t))[0].n

  if ((await n(firmSettings)) === 0) {
    await db.insert(firmSettings).values({
      id: 'main', firmName: c.firmName, tagline: c.tagline, description: c.description, logoUrl: c.logoUrl, address: c.address,
      city: c.city, state: c.state, country: c.country, phone: c.phone, email: c.email, whatsapp: c.whatsapp,
      mapsEmbedUrl: c.mapsEmbedUrl, mapsDirectionsUrl: c.mapsDirectionsUrl, businessHours: c.businessHours,
      serviceAreas: c.serviceAreas, studioVideoUrl: STUDIO_VIDEO_DEFAULT, socialLinks: { ...c.social },
    })
    done.push('settings')
  }
  if ((await n(services)) === 0) {
    await db.insert(services).values(c.services.map((s, i) => ({ title: s.title, slug: s.slug, summary: s.summary, details: s.details, sortOrder: i })))
    done.push('services')
  }
  if ((await n(projects)) === 0) {
    await db.insert(projects).values(c.projects.map((p, i) => ({
      slug: p.slug, title: p.title, location: p.location, year: p.year, projectType: p.type, status: p.status, area: p.area,
      shortDescription: p.shortDescription, description: clean(p.description), concept: clean(p.concept),
      coverImage: p.coverImage, gallery: [] as string[], videoUrl: p.videoUrl, mapsUrl: p.mapsUrl, sortOrder: i, published: true,
    })))
    done.push('projects')
  }
  if ((await n(media)) === 0) {
    await db.insert(media).values(gallerySeed.map((g, i) => ({
      title: g.title, kind: 'image', category: g.category, url: g.url, thumbUrl: g.thumbUrl ?? null, width: g.width ?? null, height: g.height ?? null, sortOrder: i,
    })))
    done.push('gallery')
  }
  revalidatePath('/', 'layout')
  return NextResponse.json({ ok: true, imported: done })
}
