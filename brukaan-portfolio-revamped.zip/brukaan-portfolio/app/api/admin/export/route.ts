import { desc } from 'drizzle-orm'
import { db } from '@/lib/db'
import { inquiries } from '@/lib/db/schema'
import { denyUnlessAdmin } from '@/lib/admin-auth'

export const dynamic = 'force-dynamic'
const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""').replace(/^([=+\-@])/, "'$1")}"` // neutralise CSV/Excel formula injection

export async function GET() {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  const rows = await db.select().from(inquiries).orderBy(desc(inquiries.createdAt))
  const head = ['Date', 'Name', 'Email', 'Phone', 'Project type', 'Location', 'Size/Budget', 'Status', 'Message']
  const lines = rows.map((r) => [r.createdAt.toISOString(), r.name, r.email, r.phone, r.projectType, r.location, r.sizeOrBudget, r.status, r.message].map(q).join(','))
  return new Response([head.map(q).join(','), ...lines].join('\n'), {
    headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="brukaan-enquiries.csv"' },
  })
}
