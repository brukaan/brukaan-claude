import { NextResponse } from 'next/server'
import { denyUnlessAdmin } from '@/lib/admin-auth'

export const dynamic = 'force-dynamic'
export async function GET() {
  const denied = await denyUnlessAdmin(); if (denied) return denied
  return NextResponse.json({ ok: true, uploads: Boolean(process.env.BLOB_READ_WRITE_TOKEN), email: Boolean(process.env.RESEND_API_KEY && process.env.INQUIRY_TO_EMAIL) })
}
