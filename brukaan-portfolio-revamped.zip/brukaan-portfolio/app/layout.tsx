import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'

const SITE = process.env.BETTER_AUTH_URL || 'https://brukaandesigns.com'

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: { default: 'Brukaan Designers & Associates | Luxury Architecture & Interior Design', template: '%s | Brukaan Designers & Associates' },
  description: 'Luxury architecture, interior design, landscape and Vastu consultancy studio in Bhubaneswar and Navi Mumbai.',
  openGraph: { type: 'website', siteName: 'Brukaan Designers & Associates', images: ['/gallery/exteriors-11.jpg'] },
  twitter: { card: 'summary_large_image' },
  icons: { icon: [{ url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' }, { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' }, { url: '/icon.svg', type: 'image/svg+xml' }], apple: '/apple-icon.png' },
}
export const viewport: Viewport = { colorScheme: 'light', themeColor: '#07162d' }

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Jost:wght@300;400;500&display=swap" rel="stylesheet" />
      </head>
      <body>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
