import type { MetadataRoute } from 'next'
import { getProjects } from '@/lib/data'

export const revalidate = 3600
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.BETTER_AUTH_URL || 'https://brukaandesigns.com'
  const projects = await getProjects()
  return [
    { url: base, lastModified: new Date(), priority: 1 },
    { url: `${base}/gallery`, lastModified: new Date(), priority: 0.8 },
    ...projects.map((p) => ({ url: `${base}/projects/${p.slug}`, lastModified: new Date(), priority: 0.6 })),
  ]
}
