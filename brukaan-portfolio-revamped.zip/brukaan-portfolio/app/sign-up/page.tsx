'use client'

import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'
import { authClient } from '@/lib/auth-client'

// Registration is locked server-side: only the first account (or emails in ADMIN_EMAILS) can be created.
export default function SignUpPage() {
  const router = useRouter()
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError('')
    const f = new FormData(e.currentTarget)
    const r = await authClient.signUp.email({ name: String(f.get('name')), email: String(f.get('email')), password: String(f.get('password')) })
    setBusy(false)
    if (r.error) setError(r.error.message || 'Unable to create account'); else router.push('/admin')
  }
  return (
    <main className="auth-page"><form className="auth-card" onSubmit={submit}>
      <a href="/" className="eyebrow">← Brukaan</a><h1>Create <em>owner account</em></h1>
      <p style={{ opacity: .7, margin: 0, fontSize: 14 }}>The first account becomes the studio administrator. After that, registration closes automatically.</p>
      <label>Name<input name="name" required autoComplete="name" /></label>
      <label>Email<input name="email" type="email" required autoComplete="email" /></label>
      <label>Password (min. 10 characters)<input name="password" type="password" minLength={10} required autoComplete="new-password" /></label>
      <button className="btn" disabled={busy}>{busy ? 'Creating…' : 'Create account'}</button>
      {error && <p role="alert" className="form-error">{error}</p>}
    </form></main>
  )
}
