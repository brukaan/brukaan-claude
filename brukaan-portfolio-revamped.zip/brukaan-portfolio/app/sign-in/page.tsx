'use client'

import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'
import { authClient } from '@/lib/auth-client'

export default function SignInPage() {
  const router = useRouter()
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError('')
    const f = new FormData(e.currentTarget)
    const r = await authClient.signIn.email({ email: String(f.get('email')), password: String(f.get('password')) })
    setBusy(false)
    if (r.error) setError(r.error.message || 'Unable to sign in'); else router.push('/admin')
  }
  return (
    <main className="auth-page"><form className="auth-card" onSubmit={submit}>
      <a href="/" className="eyebrow">← Brukaan</a><h1>Studio <em>sign in</em></h1>
      <label>Email<input name="email" type="email" required autoComplete="email" /></label>
      <label>Password<input name="password" type="password" required autoComplete="current-password" /></label>
      <button className="btn" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      {error && <p role="alert" className="form-error">{error}</p>}
    </form></main>
  )
}
