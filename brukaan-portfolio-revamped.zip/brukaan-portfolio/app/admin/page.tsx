import { redirect } from 'next/navigation'
import { getAdmin } from '@/lib/admin-auth'
import { AdminApp } from '@/components/admin/admin-app'
import './admin.css'

export const dynamic = 'force-dynamic'
export const metadata = { title: 'Studio Admin', robots: { index: false, follow: false } }

export default async function AdminPage() {
  const user = await getAdmin()
  if (!user) redirect('/sign-in')
  return <AdminApp userName={user.name || user.email} />
}
