import type { Metadata } from 'next'
import { getGallery, getSettings } from '@/lib/data'
import { galleryCategories } from '@/lib/gallery-seed'
import { SiteHeader } from '@/components/site/header'
import { Gallery } from '@/components/site/gallery'
import { SiteFooter } from '@/components/site/footer'
import { WhatsAppFloat } from '@/components/site/whatsapp-float'

export const revalidate = 60
export const metadata: Metadata = {
  title: 'Portfolio',
  description: 'Browse luxury residences, interiors, landscapes, pooja rooms and more by Brukaan Designers & Associates.',
  alternates: { canonical: '/gallery' },
}

export default async function GalleryPage() {
  const [s, items] = await Promise.all([getSettings(), getGallery()])
  return (
    <main>
      <SiteHeader firmName={s.firmName} logoUrl={s.logoUrl} forceSolid />
      <div className="page-top"><a className="back" href="/">← Back home</a><p className="label">Portfolio</p><h1>The complete <em>gallery</em></h1></div>
      <section style={{ padding: '40px var(--pad) 120px' }}><div className="container"><Gallery items={items} categories={galleryCategories} /></div></section>
      <SiteFooter s={s} />
      <WhatsAppFloat number={s.whatsapp} />
    </main>
  )
}
