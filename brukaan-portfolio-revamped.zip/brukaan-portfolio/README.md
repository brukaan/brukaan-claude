# Brukaan Designers & Associates — website + admin

Next.js 16 · Postgres (Neon) · Drizzle · better-auth · Vercel Blob (optional) · Resend (optional)

## Go live
1. Copy `.env.example` to `.env.local` (and add the same variables in Vercel → Settings → Environment Variables).
2. Create the tables — either run `pnpm db:push`, or paste `db/migrations/0000_*.sql` into the Neon SQL editor.
3. `pnpm install && pnpm build` (or just deploy to Vercel).
4. Visit `/sign-up` and create the owner account. Registration then closes automatically
   (or is limited to `ADMIN_EMAILS`).
5. Open `/admin` → Dashboard → **Import default content** (studio details, services, projects, 68-photo gallery).

## Admin (`/admin`)
Dashboard · Enquiries (status, reply, CSV export) · Gallery (bulk upload, categories, hide/show) ·
Projects · Services · Studio settings. Edits appear on the site within ~1 minute (immediately for most changes).

## Notes
- The site falls back to built-in content if the database is empty or unreachable, so it never shows a blank page.
- Gallery photos live in `public/gallery` (full + `thumbs/`). Uploads from the admin go to Vercel Blob.
- Uploaded photos are compressed in the browser (max 1800px) before sending.
- Named projects need photos: Admin → Projects → edit → Cover image / Gallery images.
