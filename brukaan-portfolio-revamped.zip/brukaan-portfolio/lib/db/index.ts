import { drizzle } from 'drizzle-orm/node-postgres'
import { Pool } from 'pg'
import * as schema from './schema'

export const hasDatabase = Boolean(process.env.DATABASE_URL)

// Reuse the pool across hot reloads / serverless invocations.
const globalForPg = globalThis as unknown as { __brukaanPool?: Pool }

export const pool =
  globalForPg.__brukaanPool ??
  new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 5,
    connectionTimeoutMillis: 5000,
    idleTimeoutMillis: 20000,
  })
if (process.env.NODE_ENV !== 'production') globalForPg.__brukaanPool = pool

export const db = drizzle(pool, { schema })
