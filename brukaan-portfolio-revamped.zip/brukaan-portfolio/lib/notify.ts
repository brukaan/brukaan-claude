import 'server-only'

type Inquiry = { name: string; email: string; phone?: string | null; projectType?: string | null; location?: string | null; sizeOrBudget?: string | null; message: string }
const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!)

/** Emails the studio when an enquiry arrives. Needs RESEND_API_KEY + INQUIRY_TO_EMAIL; silently skipped otherwise. */
export async function notifyStudio(i: Inquiry) {
  const key = process.env.RESEND_API_KEY, to = process.env.INQUIRY_TO_EMAIL
  if (!key || !to) return
  const rows = [['Name', i.name], ['Email', i.email], ['Phone', i.phone], ['Project type', i.projectType], ['Location', i.location], ['Size / budget', i.sizeOrBudget]]
    .filter(([, v]) => v).map(([k, v]) => `<tr><td style="padding:4px 12px 4px 0;color:#666">${k}</td><td>${esc(String(v))}</td></tr>`).join('')
  try {
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: process.env.INQUIRY_FROM_EMAIL || 'Brukaan Website <onboarding@resend.dev>',
        to: to.split(',').map((x) => x.trim()), reply_to: i.email,
        subject: `New enquiry from ${i.name}`,
        html: `<table style="font:14px Arial">${rows}</table><p style="font:14px/1.6 Arial;white-space:pre-wrap">${esc(i.message)}</p>`,
      }),
    })
  } catch (e) {
    console.error('[notify] email failed:', (e as Error).message)
  }
}
