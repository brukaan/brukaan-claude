import 'server-only'
import { media, projects, services, inquiries } from '@/lib/db/schema'
import { resources, slugify, type Field } from '@/lib/admin-resources'

export const tables = { projects, services, media, inquiries } as const
export type ResourceName = keyof typeof tables
export const isResource = (v: string): v is ResourceName => v in tables

const NOT_NULL_TEXT = new Set(['title', 'slug', 'url', 'category', 'status'])

/** Validate + coerce a request body into a DB-ready object using the shared field definitions. */
export function buildPayload(resource: ResourceName, body: Record<string, unknown>, mode: 'create' | 'update') {
  const def = resources[resource]
  const out: Record<string, unknown> = {}
  const errors: string[] = []

  for (const f of def.fields as Field[]) {
    if (f.readOnly && !(resource === 'inquiries' && f.name === 'status')) continue
    if (!(f.name in body)) {
      if (mode === 'create' && f.required) errors.push(`${f.label} is required`)
      continue
    }
    const raw = body[f.name]
    switch (f.type) {
      case 'boolean': out[f.name] = Boolean(raw); break
      case 'number': {
        if (raw === '' || raw === null || raw === undefined) { out[f.name] = f.name === 'sortOrder' ? 0 : null; break }
        const n = Number(raw)
        if (!Number.isFinite(n)) errors.push(`${f.label} must be a number`)
        else out[f.name] = Math.trunc(n)
        break
      }
      case 'images': {
        const arr = Array.isArray(raw) ? raw.filter((x): x is string => typeof x === 'string' && x.trim() !== '') : []
        out[f.name] = arr.slice(0, 80)
        break
      }
      case 'select': {
        const v = typeof raw === 'string' ? raw : ''
        if (v && f.options && !f.options.some((o) => o.value === v)) errors.push(`${f.label} has an invalid value`)
        else if (v) out[f.name] = v
        break
      }
      default: {
        const v = typeof raw === 'string' ? raw.trim().slice(0, 8000) : ''
        if (f.required && !v) errors.push(`${f.label} is required`)
        out[f.name] = v === '' && !NOT_NULL_TEXT.has(f.name) ? null : v
      }
    }
  }

  if (def.fields.some((f) => f.name === 'slug')) {
    const fromSlug = typeof out.slug === 'string' ? slugify(out.slug) : ''
    const fromTitle = typeof out.title === 'string' ? slugify(out.title) : ''
    if (mode === 'create') out.slug = fromSlug || fromTitle || `item-${Date.now()}`
    else if ('slug' in out) { if (fromSlug || fromTitle) out.slug = fromSlug || fromTitle; else delete out.slug }
  }
  return { data: out, errors }
}
