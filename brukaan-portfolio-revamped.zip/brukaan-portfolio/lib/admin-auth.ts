import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import { auth } from '@/lib/auth'

/** Returns the signed-in admin user or null. */
export async function getAdmin() {
  try {
    const session = await auth.api.getSession({ headers: await headers() })
    return session?.user ?? null
  } catch {
    return null
  }
}

/** For API routes: returns a 401 response if not signed in, otherwise null. */
export async function denyUnlessAdmin() {
  const user = await getAdmin()
  return user ? null : NextResponse.json({ ok: false, error: 'Unauthorised' }, { status: 401 })
}
