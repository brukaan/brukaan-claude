import 'server-only'
import { asc, desc, eq } from 'drizzle-orm'
import { db, hasDatabase } from '@/lib/db'
import { firmSettings, media, projects, services } from '@/lib/db/schema'
import { siteConfig } from '@/lib/site-config'
import { gallerySeed, type GalleryItem } from '@/lib/gallery-seed'

export const STUDIO_VIDEO_DEFAULT = 'https://www.youtube.com/embed/ltrkI5KjcP4'

/** Hide leftover "Add the detailed description…" placeholder copy from public pages. */
export function clean(text?: string | null): string {
  const t = (text ?? '').trim()
  return /^add (the|a|an)\b/i.test(t) ? '' : t
}

export type Settings = {
  firmName: string; tagline: string; description: string; logoUrl: string
  address: string; city: string; state: string; country: string
  phone: string; email: string; whatsapp: string
  mapsEmbedUrl: string; mapsDirectionsUrl: string
  businessHours: string; serviceAreas: string; studioVideoUrl: string
  social: { instagram: string; facebook: string; linkedin: string; youtube: string; pinterest: string }
}
export type PublicProject = {
  slug: string; title: string; location: string; year: string; type: string; status: string; area: string
  shortDescription: string; description: string; concept: string; coverImage: string; gallery: string[]
  videoUrl: string; mapsUrl: string
}
export type PublicService = { slug: string; title: string; summary: string; details: string }

const s = (v: unknown) => (typeof v === 'string' ? v : '')

function fallbackSettings(): Settings {
  const c = siteConfig
  return {
    firmName: c.firmName, tagline: c.tagline, description: c.description, logoUrl: c.logoUrl,
    address: c.address, city: c.city, state: c.state, country: c.country,
    phone: c.phone, email: c.email, whatsapp: c.whatsapp,
    mapsEmbedUrl: c.mapsEmbedUrl, mapsDirectionsUrl: c.mapsDirectionsUrl,
    businessHours: c.businessHours, serviceAreas: c.serviceAreas, studioVideoUrl: STUDIO_VIDEO_DEFAULT,
    social: { ...c.social },
  }
}

export async function getSettings(): Promise<Settings> {
  const base = fallbackSettings()
  if (!hasDatabase) return base
  try {
    const [row] = await db.select().from(firmSettings).where(eq(firmSettings.id, 'main')).limit(1)
    if (!row) return base
    const social = { ...base.social, ...((row.socialLinks as Record<string, string>) || {}) }
    const pick = (v: string | null, d: string) => (v && v.trim() ? v : d)
    return {
      firmName: pick(row.firmName, base.firmName), tagline: pick(row.tagline, base.tagline),
      description: pick(row.description, base.description), logoUrl: pick(row.logoUrl, base.logoUrl),
      address: pick(row.address, base.address), city: pick(row.city, base.city),
      state: pick(row.state, base.state), country: pick(row.country, base.country),
      phone: pick(row.phone, base.phone), email: pick(row.email, base.email), whatsapp: pick(row.whatsapp, base.whatsapp),
      mapsEmbedUrl: pick(row.mapsEmbedUrl, base.mapsEmbedUrl), mapsDirectionsUrl: pick(row.mapsDirectionsUrl, base.mapsDirectionsUrl),
      businessHours: pick(row.businessHours, base.businessHours), serviceAreas: pick(row.serviceAreas, base.serviceAreas),
      studioVideoUrl: pick(row.studioVideoUrl, base.studioVideoUrl), social,
    }
  } catch (e) {
    console.error('[data] settings fallback:', (e as Error).message)
    return base
  }
}

const fallbackProjects = (): PublicProject[] =>
  siteConfig.projects.map((p) => ({
    slug: p.slug, title: p.title, location: p.location, year: p.year, type: p.type, status: p.status, area: p.area,
    shortDescription: p.shortDescription, description: clean(p.description), concept: clean(p.concept),
    coverImage: p.coverImage, gallery: [...p.gallery], videoUrl: p.videoUrl, mapsUrl: p.mapsUrl,
  }))

type ProjectRow = typeof projects.$inferSelect
const mapProject = (r: ProjectRow): PublicProject => ({
  slug: r.slug, title: r.title, location: s(r.location), year: s(r.year), type: s(r.projectType), status: s(r.status), area: s(r.area),
  shortDescription: clean(r.shortDescription), description: clean(r.description), concept: clean(r.concept),
  coverImage: s(r.coverImage), gallery: Array.isArray(r.gallery) ? (r.gallery as string[]) : [],
  videoUrl: s(r.videoUrl), mapsUrl: s(r.mapsUrl),
})

export async function getProjects(): Promise<PublicProject[]> {
  if (!hasDatabase) return fallbackProjects()
  try {
    const rows = await db.select().from(projects).where(eq(projects.published, true)).orderBy(asc(projects.sortOrder), asc(projects.id))
    if (rows.length) return rows.map(mapProject)
    const [any] = await db.select({ id: projects.id }).from(projects).limit(1)
    return any ? [] : fallbackProjects() // empty table = never seeded; rows-but-none-published = intentionally empty
  } catch (e) {
    console.error('[data] projects fallback:', (e as Error).message)
    return fallbackProjects()
  }
}

export async function getProject(slug: string) {
  return (await getProjects()).find((p) => p.slug === slug) ?? null
}

export async function getServices(): Promise<PublicService[]> {
  const fb = () => siteConfig.services.map((x) => ({ slug: x.slug, title: x.title, summary: x.summary, details: x.details }))
  if (!hasDatabase) return fb()
  try {
    const rows = await db.select().from(services).where(eq(services.published, true)).orderBy(asc(services.sortOrder), asc(services.id))
    if (rows.length) return rows.map((r) => ({ slug: r.slug, title: r.title, summary: s(r.summary), details: s(r.details) }))
    const [any] = await db.select({ id: services.id }).from(services).limit(1)
    return any ? [] : fb()
  } catch (e) {
    console.error('[data] services fallback:', (e as Error).message)
    return fb()
  }
}

export async function getGallery(): Promise<GalleryItem[]> {
  if (!hasDatabase) return gallerySeed
  try {
    const rows = await db.select().from(media).where(eq(media.published, true)).orderBy(asc(media.sortOrder), desc(media.id))
    const imgs = rows.filter((r) => r.kind === 'image')
    if (imgs.length) return imgs.map((r) => ({ id: r.id, title: r.title, category: r.category, url: r.url, thumbUrl: r.thumbUrl, width: r.width, height: r.height, caption: r.caption }))
    const [any] = await db.select({ id: media.id }).from(media).limit(1)
    return any ? [] : gallerySeed
  } catch (e) {
    console.error('[data] gallery fallback:', (e as Error).message)
    return gallerySeed
  }
}

export function youtubeEmbed(url?: string): string {
  if (!url) return ''
  try {
    if (url.includes('/embed/')) return url
    const u = new URL(url)
    const id = u.hostname.includes('youtu.be') ? u.pathname.slice(1) : u.searchParams.get('v')
    return id ? `https://www.youtube.com/embed/${id}` : ''
  } catch {
    return /^[\w-]{11}$/.test(url) ? `https://www.youtube.com/embed/${url}` : ''
  }
}
