import { betterAuth } from 'better-auth'
import { APIError } from 'better-auth/api'
import { pool } from '@/lib/db'

const baseURL =
  process.env.BETTER_AUTH_URL ||
  (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : undefined) ||
  (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : undefined) ||
  'http://localhost:3000'

const origins = [
  baseURL,
  'https://brukaandesigns.com',
  'https://www.brukaandesigns.com',
  process.env.VERCEL_URL && `https://${process.env.VERCEL_URL}`,
].filter(Boolean) as string[]

/**
 * Admin accounts are NOT open to the public.
 *  - If ADMIN_EMAILS is set (comma separated), only those emails can register.
 *  - Otherwise only the very first account can be created (the owner); after
 *    that, registration is closed.
 */
async function assertMaySignUp(email: string) {
  const allow = (process.env.ADMIN_EMAILS || '').split(',').map((e) => e.trim().toLowerCase()).filter(Boolean)
  if (allow.length) {
    if (!allow.includes(email.toLowerCase())) throw new APIError('FORBIDDEN', { message: 'This email is not authorised to create an account.' })
    return
  }
  const { rows } = await pool.query('select count(*)::int as n from "user"')
  if (rows[0].n > 0) throw new APIError('FORBIDDEN', { message: 'Registration is closed. Ask the studio owner for access.' })
}

export const auth = betterAuth({
  database: pool,
  baseURL,
  trustedOrigins: origins,
  secret: process.env.BETTER_AUTH_SECRET,
  emailAndPassword: { enabled: true, minPasswordLength: 10 },
  session: { expiresIn: 60 * 60 * 24 * 7 },
  databaseHooks: {
    user: {
      create: {
        before: async (user) => {
          await assertMaySignUp(user.email)
          return { data: user }
        },
      },
    },
  },
})
