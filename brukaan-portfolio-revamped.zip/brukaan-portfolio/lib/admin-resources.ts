// Shared (client + server) field definitions that drive both the admin forms and API validation.
import { galleryCategories } from '@/lib/gallery-seed'

export type FieldType = 'text' | 'textarea' | 'select' | 'boolean' | 'number' | 'image' | 'images'
export type Field = {
  name: string; label: string; type: FieldType
  options?: { value: string; label: string }[]
  required?: boolean; help?: string; showInList?: boolean; readOnly?: boolean
}
export type ResourceDef = {
  label: string; singular: string; titleField: string; fields: Field[]
  canCreate: boolean; canDelete: boolean
}

const categoryOptions = Object.entries(galleryCategories).map(([value, label]) => ({ value, label }))
const opt = (...v: string[]) => v.map((x) => ({ value: x, label: x }))

export const resources: Record<string, ResourceDef> = {
  projects: {
    label: 'Projects', singular: 'project', titleField: 'title', canCreate: true, canDelete: true,
    fields: [
      { name: 'title', label: 'Project name', type: 'text', required: true, showInList: true },
      { name: 'slug', label: 'URL slug', type: 'text', help: 'Leave blank to generate from the name.' },
      { name: 'projectType', label: 'Type', type: 'text', showInList: true, help: 'e.g. Luxury Jewellery Showroom' },
      { name: 'status', label: 'Status', type: 'select', options: opt('Completed', 'Ongoing', 'Concept'), showInList: true },
      { name: 'location', label: 'Location', type: 'text' },
      { name: 'year', label: 'Year', type: 'text' },
      { name: 'area', label: 'Area', type: 'text', help: 'e.g. 12,000 sq ft' },
      { name: 'shortDescription', label: 'Short description', type: 'textarea' },
      { name: 'description', label: 'Full description / approach', type: 'textarea' },
      { name: 'concept', label: 'Design concept', type: 'textarea' },
      { name: 'coverImage', label: 'Cover image', type: 'image' },
      { name: 'gallery', label: 'Gallery images', type: 'images' },
      { name: 'videoUrl', label: 'Video URL (YouTube)', type: 'text' },
      { name: 'mapsUrl', label: 'Google Maps link', type: 'text' },
      { name: 'sortOrder', label: 'Display order', type: 'number', help: 'Lower numbers appear first.' },
      { name: 'published', label: 'Visible on website', type: 'boolean', showInList: true },
    ],
  },
  services: {
    label: 'Services', singular: 'service', titleField: 'title', canCreate: true, canDelete: true,
    fields: [
      { name: 'title', label: 'Service name', type: 'text', required: true, showInList: true },
      { name: 'slug', label: 'URL slug', type: 'text' },
      { name: 'summary', label: 'One-line summary', type: 'text', showInList: true },
      { name: 'details', label: 'Details', type: 'textarea' },
      { name: 'sortOrder', label: 'Display order', type: 'number' },
      { name: 'published', label: 'Visible on website', type: 'boolean', showInList: true },
    ],
  },
  media: {
    label: 'Gallery', singular: 'image', titleField: 'title', canCreate: true, canDelete: true,
    fields: [
      { name: 'title', label: 'Title', type: 'text', required: true, showInList: true },
      { name: 'category', label: 'Category', type: 'select', options: categoryOptions, required: true, showInList: true },
      { name: 'url', label: 'Image', type: 'image', required: true },
      { name: 'thumbUrl', label: 'Thumbnail URL', type: 'text', help: 'Optional smaller version for faster loading.' },
      { name: 'caption', label: 'Caption', type: 'text' },
      { name: 'width', label: 'Width (px)', type: 'number' },
      { name: 'height', label: 'Height (px)', type: 'number' },
      { name: 'sortOrder', label: 'Display order', type: 'number' },
      { name: 'published', label: 'Visible on website', type: 'boolean', showInList: true },
    ],
  },
  inquiries: {
    label: 'Enquiries', singular: 'enquiry', titleField: 'name', canCreate: false, canDelete: true,
    fields: [
      { name: 'name', label: 'Name', type: 'text', readOnly: true, showInList: true },
      { name: 'email', label: 'Email', type: 'text', readOnly: true, showInList: true },
      { name: 'phone', label: 'Phone', type: 'text', readOnly: true },
      { name: 'projectType', label: 'Project type', type: 'text', readOnly: true, showInList: true },
      { name: 'location', label: 'Location', type: 'text', readOnly: true },
      { name: 'sizeOrBudget', label: 'Size / budget', type: 'text', readOnly: true },
      { name: 'message', label: 'Message', type: 'textarea', readOnly: true },
      { name: 'status', label: 'Status', type: 'select', options: opt('new', 'contacted', 'closed'), showInList: true },
    ],
  },
}

export const settingsFields: Field[] = [
  { name: 'firmName', label: 'Firm name', type: 'text', required: true },
  { name: 'tagline', label: 'Tagline', type: 'text' },
  { name: 'description', label: 'Studio description', type: 'textarea' },
  { name: 'phone', label: 'Phone', type: 'text' },
  { name: 'email', label: 'Email', type: 'text' },
  { name: 'whatsapp', label: 'WhatsApp number (country code, digits only)', type: 'text', help: 'e.g. 919337720201' },
  { name: 'address', label: 'Address', type: 'textarea' },
  { name: 'city', label: 'City', type: 'text' },
  { name: 'state', label: 'State', type: 'text' },
  { name: 'country', label: 'Country', type: 'text' },
  { name: 'businessHours', label: 'Business hours', type: 'text' },
  { name: 'serviceAreas', label: 'Service areas', type: 'text' },
  { name: 'mapsEmbedUrl', label: 'Google Maps embed URL', type: 'text' },
  { name: 'mapsDirectionsUrl', label: 'Google Maps directions link', type: 'text' },
  { name: 'studioVideoUrl', label: 'Studio film (YouTube URL)', type: 'text' },
  { name: 'instagram', label: 'Instagram URL', type: 'text' },
  { name: 'facebook', label: 'Facebook URL', type: 'text' },
  { name: 'linkedin', label: 'LinkedIn URL', type: 'text' },
  { name: 'youtube', label: 'YouTube channel URL', type: 'text' },
  { name: 'pinterest', label: 'Pinterest URL', type: 'text' },
]

export const slugify = (v: string) =>
  v.toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 80)
