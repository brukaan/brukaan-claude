// Browser-side image helpers: shrink phone/camera photos before upload (keeps requests under host body limits).
export type Prepared = { full: Blob; thumb: Blob; width: number; height: number }

function load(file: File) {
  return new Promise<HTMLImageElement>((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image()
    img.onload = () => { URL.revokeObjectURL(url); res(img) }
    img.onerror = () => rej(new Error(`Could not read ${file.name}`))
    img.src = url
  })
}
function render(img: HTMLImageElement, max: number, q: number) {
  const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight))
  const w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k)
  const c = document.createElement('canvas'); c.width = w; c.height = h
  c.getContext('2d')!.drawImage(img, 0, 0, w, h)
  return new Promise<{ blob: Blob; w: number; h: number }>((res, rej) => c.toBlob((b) => (b ? res({ blob: b, w, h }) : rej(new Error('Compression failed'))), 'image/jpeg', q))
}
export async function prepareImage(file: File): Promise<Prepared> {
  const img = await load(file)
  const full = await render(img, 1800, 0.84), thumb = await render(img, 720, 0.78)
  return { full: full.blob, thumb: thumb.blob, width: full.w, height: full.h }
}
export async function uploadBlob(blob: Blob, name: string): Promise<string> {
  const fd = new FormData(); fd.append('file', new File([blob], name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }))
  const res = await fetch('/api/admin/upload', { method: 'POST', body: fd })
  const data = await res.json().catch(() => ({}))
  if (!res.ok || !data.url) throw new Error(data.error || 'Upload failed')
  return data.url as string
}
