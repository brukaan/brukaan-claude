'use client'

import { useEffect, useState } from 'react'
import { ArrowUpRight } from 'lucide-react'

export function Hero({ slides, tagline, offices }: { slides: string[]; tagline: string; offices: string }) {
  const [i, setI] = useState(0)
  useEffect(() => {
    if (slides.length < 2 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const t = setInterval(() => setI((n) => (n + 1) % slides.length), 6500)
    return () => clearInterval(t)
  }, [slides.length])

  return (
    <section id="top" className="hero">
      <div className="hero-slides" aria-hidden="true">
        {slides.map((src, n) => <div key={src} className={`hero-slide ${n === i ? 'active' : ''}`} style={{ backgroundImage: `url(${src})` }} />)}
      </div>
      <div className="hero-copy">
        <p className="eyebrow">Brukaan Designers &amp; Associates</p>
        <h1>Spaces with a distinct <em>sense of place.</em></h1>
        <p className="sub">{tagline}. Residences, interiors and landscapes composed with material, light and proportion.</p>
        <div className="hero-actions">
          <a className="btn btn-solid" href="#portfolio">View portfolio <ArrowUpRight size={15} /></a>
          <a className="btn" href="#contact">Start a project <ArrowUpRight size={15} /></a>
        </div>
      </div>
      <div className="hero-foot">
        <span>{offices}</span>
        <span>Architecture · Interiors · Landscape</span>
        <div className="hero-dots" role="tablist" aria-label="Hero images">
          {slides.map((_, n) => <button key={n} role="tab" aria-selected={n === i} aria-label={`Image ${n + 1}`} className={n === i ? 'active' : ''} onClick={() => setI(n)} />)}
        </div>
      </div>
    </section>
  )
}
