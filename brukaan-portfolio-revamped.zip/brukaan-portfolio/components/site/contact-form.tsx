'use client'

import { FormEvent, useState } from 'react'
import { ArrowUpRight, Check } from 'lucide-react'

const TYPES = ['Architecture', 'Interior Design', 'Vastu Consultancy', 'Landscaping', 'Urban Planning', 'Project Management', 'Other']

export function ContactForm({ whatsapp }: { whatsapp?: string }) {
  const [state, setState] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [message, setMessage] = useState('')

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget
    setState('loading'); setErrors({}); setMessage('')
    try {
      const res = await fetch('/api/inquiries', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(form).entries())) })
      const data = await res.json().catch(() => ({}))
      if (res.ok) { setState('success'); form.reset(); return }
      setErrors(data.errors ?? {}); setMessage(data.error ?? (data.errors ? 'Please check the highlighted fields.' : 'Something went wrong.'))
      setState('error')
    } catch {
      setMessage('Could not reach the server. Please check your connection or contact us directly.'); setState('error')
    }
  }
  const Err = ({ k }: { k: string }) => (errors[k] ? <span className="err" role="alert">{errors[k]}</span> : null)

  if (state === 'success') {
    return (
      <div className="contact-form"><p className="form-note ok full" role="status"><Check size={16} style={{ display: 'inline', marginRight: 8 }} />
        Thank you — your enquiry has reached the studio. We will respond shortly{whatsapp ? <>, or <a href={`https://wa.me/${whatsapp}`} style={{ textDecoration: 'underline' }}>message us on WhatsApp</a> for a faster reply</> : ''}.</p>
        <button className="btn full" onClick={() => setState('idle')}>Send another enquiry</button></div>
    )
  }
  return (
    <form className="contact-form" onSubmit={submit} noValidate>
      <label>Name *<input name="name" required autoComplete="name" placeholder="Your name" /><Err k="name" /></label>
      <label>Email *<input name="email" type="email" required autoComplete="email" placeholder="you@example.com" /><Err k="email" /></label>
      <label>Phone<input name="phone" type="tel" autoComplete="tel" placeholder="Optional" /></label>
      <label>Project type<select name="projectType" defaultValue=""><option value="">Select one</option>{TYPES.map((t) => <option key={t}>{t}</option>)}</select></label>
      <label>Location<input name="location" placeholder="Project location" /></label>
      <label>Approx. size / budget<input name="sizeOrBudget" placeholder="Optional" /></label>
      <label className="full">Tell us about your project *<textarea name="message" required rows={5} placeholder="Plot size, the spaces you imagine, timeline…" /><Err k="message" /></label>
      <div className="hp" aria-hidden="true"><label>Website<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
      <button className="btn btn-solid full" disabled={state === 'loading'} style={{ justifyContent: 'center' }}>{state === 'loading' ? 'Sending…' : 'Send enquiry'} <ArrowUpRight size={15} /></button>
      {state === 'error' && message && <p className="form-note full" role="alert">{message}</p>}
    </form>
  )
}
