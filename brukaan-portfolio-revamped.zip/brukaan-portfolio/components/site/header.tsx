'use client'

import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'

const NAV = [['Studio', '/#studio'], ['Portfolio', '/#portfolio'], ['Services', '/#services'], ['Projects', '/#projects'], ['Approach', '/#approach']] as const

export function SiteHeader({ firmName, logoUrl, forceSolid = false }: { firmName: string; logoUrl: string; forceSolid?: boolean }) {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 60)
    on(); window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [])
  useEffect(() => { document.body.style.overflow = open ? 'hidden' : '' }, [open])

  return (
    <header className={`site-header ${scrolled || forceSolid ? 'solid' : ''}`}>
      <a href="/" className="brand" aria-label={`${firmName} — home`}>
        <span className="brand-mark"><img src={logoUrl} alt="" width={44} height={44} /></span>
        <span className="brand-name">BRUKAAN<small>Designers &amp; Associates</small></span>
      </a>
      <nav className={`main-nav ${open ? 'open' : ''}`} aria-label="Main navigation">
        {NAV.map(([label, href]) => <a key={href} href={href} onClick={() => setOpen(false)}>{label}</a>)}
        <a className="nav-cta" href="/#contact" onClick={() => setOpen(false)}>Enquire</a>
      </nav>
      <button className="menu-toggle" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen(!open)}>
        {open ? <X size={26} /> : <Menu size={26} />}
      </button>
    </header>
  )
}
