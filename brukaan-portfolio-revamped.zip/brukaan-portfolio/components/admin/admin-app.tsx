'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { authClient } from '@/lib/auth-client'
import { resources, settingsFields, type Field, type ResourceDef } from '@/lib/admin-resources'
import { galleryCategories } from '@/lib/gallery-seed'
import { prepareImage, uploadBlob } from '@/lib/image-client'

type Row = Record<string, any>
type Status = { uploads: boolean; email: boolean }
const TABS = ['dashboard', 'inquiries', 'media', 'projects', 'services', 'settings'] as const
type Tab = (typeof TABS)[number]
const TAB_LABEL: Record<Tab, string> = { dashboard: 'Dashboard', inquiries: 'Enquiries', media: 'Gallery', projects: 'Projects', services: 'Services', settings: 'Settings' }

async function api(path: string, init?: RequestInit) {
  const res = await fetch(path, { ...init, headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) } })
  const data = await res.json().catch(() => ({}))
  if (!res.ok || data.ok === false) throw new Error(data.error || `Request failed (${res.status})`)
  return data
}

export function AdminApp({ userName }: { userName: string }) {
  const router = useRouter()
  const [tab, setTab] = useState<Tab>('dashboard')
  const [toast, setToast] = useState<{ msg: string; bad?: boolean } | null>(null)
  const [status, setStatus] = useState<Status>({ uploads: false, email: false })
  const notify = useCallback((msg: string, bad = false) => { setToast({ msg, bad }); setTimeout(() => setToast(null), 4200) }, [])
  useEffect(() => { api('/api/admin/status').then((d) => setStatus(d)).catch(() => {}) }, [])

  return (
    <div className="adm">
      <aside className="adm-side">
        <a href="/" className="adm-brand">BRUKAAN<small>Studio admin</small></a>
        <nav>{TABS.map((t) => <button key={t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{TAB_LABEL[t]}</button>)}</nav>
        <div className="adm-foot">
          <span>{userName}</span>
          <a href="/" target="_blank" rel="noopener noreferrer">View website ↗</a>
          <button onClick={async () => { await authClient.signOut(); router.push('/sign-in') }}>Sign out</button>
        </div>
      </aside>
      <main className="adm-main">
        {tab === 'dashboard' && <Dashboard status={status} go={setTab} notify={notify} />}
        {tab === 'inquiries' && <Inquiries notify={notify} />}
        {tab === 'media' && <MediaManager notify={notify} uploads={status.uploads} />}
        {(tab === 'projects' || tab === 'services') && <Resource key={tab} name={tab} notify={notify} uploads={status.uploads} />}
        {tab === 'settings' && <SettingsForm notify={notify} />}
      </main>
      {toast && <div className={`adm-toast ${toast.bad ? 'bad' : ''}`} role="status">{toast.msg}</div>}
    </div>
  )
}

/* ------------------------------ Dashboard ------------------------------ */
function Dashboard({ status, go, notify }: { status: Status; go: (t: Tab) => void; notify: (m: string, b?: boolean) => void }) {
  const [data, setData] = useState<Record<string, Row[]> | null>(null)
  const [busy, setBusy] = useState(false)
  const load = useCallback(() => {
    Promise.all(['inquiries', 'media', 'projects', 'services'].map((r) => api(`/api/admin/${r}`).then((d) => [r, d.rows] as const)))
      .then((e) => setData(Object.fromEntries(e))).catch((e) => notify(e.message, true))
  }, [notify])
  useEffect(load, [load])

  async function seed() {
    setBusy(true)
    try { const r = await api('/api/admin/seed', { method: 'POST' }); notify(r.imported.length ? `Imported: ${r.imported.join(', ')}` : 'Nothing to import — content already exists.'); load() }
    catch (e: any) { notify(e.message, true) } finally { setBusy(false) }
  }
  if (!data) return <p className="adm-muted">Loading…</p>
  const empty = !data.media.length && !data.projects.length && !data.services.length
  const fresh = data.inquiries.filter((i) => i.status === 'new')
  return (
    <>
      <h1>Welcome back</h1>
      {empty && (
        <div className="adm-card warn"><h3>Import the default content</h3>
          <p>Your database is empty. Import the studio details, 6 services, 8 projects and the 68-photo gallery so you can start editing them.</p>
          <button className="adm-btn primary" onClick={seed} disabled={busy}>{busy ? 'Importing…' : 'Import default content'}</button></div>
      )}
      <div className="adm-stats">
        {([['inquiries', 'Enquiries', data.inquiries.length, `${fresh.length} new`], ['media', 'Gallery images', data.media.length, `${data.media.filter((m) => m.published).length} live`], ['projects', 'Projects', data.projects.length, `${data.projects.filter((m) => m.published).length} live`], ['services', 'Services', data.services.length, `${data.services.filter((m) => m.published).length} live`]] as [Tab, string, number, string][]).map(([t, l, n, s]) =>
          <button key={t} className="adm-stat" onClick={() => go(t)}><strong>{n}</strong><span>{l}</span><em>{s}</em></button>)}
      </div>
      <div className="adm-card"><h3>Setup checklist</h3>
        <ul className="adm-check">
          <li className="ok">Database connected</li>
          <li className={status.uploads ? 'ok' : ''}>Image uploads {status.uploads ? 'enabled' : '— add BLOB_READ_WRITE_TOKEN to enable (you can still paste image URLs)'}</li>
          <li className={status.email ? 'ok' : ''}>Email alerts for new enquiries {status.email ? 'enabled' : '— add RESEND_API_KEY and INQUIRY_TO_EMAIL to enable'}</li>
        </ul></div>
      <div className="adm-card"><h3>Latest enquiries</h3>
        {data.inquiries.length === 0 ? <p className="adm-muted">No enquiries yet. They will appear here the moment someone submits the contact form.</p> :
          <table className="adm-table"><tbody>{data.inquiries.slice(0, 5).map((i) => <tr key={i.id}><td><b>{i.name}</b><br /><span className="adm-muted">{i.email}</span></td><td>{i.projectType || '—'}</td><td><span className={`pill ${i.status}`}>{i.status}</span></td><td className="adm-muted">{new Date(i.createdAt).toLocaleDateString()}</td></tr>)}</tbody></table>}
        {data.inquiries.length > 0 && <button className="adm-btn" onClick={() => go('inquiries')}>Open inbox</button>}</div>
    </>
  )
}

/* ------------------------------- Inquiries ------------------------------- */
function Inquiries({ notify }: { notify: (m: string, b?: boolean) => void }) {
  const [rows, setRows] = useState<Row[] | null>(null)
  const [open, setOpen] = useState<number | null>(null)
  const [filter, setFilter] = useState('all')
  const load = useCallback(() => { api('/api/admin/inquiries').then((d) => setRows(d.rows)).catch((e) => notify(e.message, true)) }, [notify])
  useEffect(load, [load])

  async function setStatus(id: number, status: string) {
    try { await api(`/api/admin/inquiries/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }); setRows((r) => r!.map((x) => (x.id === id ? { ...x, status } : x))) } catch (e: any) { notify(e.message, true) }
  }
  async function del(id: number) {
    if (!confirm('Delete this enquiry permanently?')) return
    try { await api(`/api/admin/inquiries/${id}`, { method: 'DELETE' }); setRows((r) => r!.filter((x) => x.id !== id)); notify('Deleted') } catch (e: any) { notify(e.message, true) }
  }
  if (!rows) return <p className="adm-muted">Loading…</p>
  const shown = rows.filter((r) => filter === 'all' || r.status === filter)
  return (
    <>
      <div className="adm-head"><h1>Enquiries</h1><a className="adm-btn" href="/api/admin/export">Export CSV</a></div>
      <div className="adm-tabs">{['all', 'new', 'contacted', 'closed'].map((f) => <button key={f} className={filter === f ? 'on' : ''} onClick={() => setFilter(f)}>{f}{f === 'all' ? ` (${rows.length})` : ` (${rows.filter((r) => r.status === f).length})`}</button>)}</div>
      {shown.length === 0 && <p className="adm-muted">Nothing here.</p>}
      {shown.map((r) => (
        <div key={r.id} className={`adm-inq ${r.status}`}>
          <button className="adm-inq-head" onClick={() => setOpen(open === r.id ? null : r.id)}>
            <span><b>{r.name}</b> <span className="adm-muted">· {r.projectType || 'General'}{r.location ? ` · ${r.location}` : ''}</span></span>
            <span><span className={`pill ${r.status}`}>{r.status}</span> <span className="adm-muted">{new Date(r.createdAt).toLocaleString()}</span></span>
          </button>
          {open === r.id && (
            <div className="adm-inq-body">
              <p style={{ whiteSpace: 'pre-wrap' }}>{r.message}</p>
              <dl>{[['Email', r.email], ['Phone', r.phone], ['Size / budget', r.sizeOrBudget]].filter(([, v]) => v).map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}</dl>
              <div className="adm-row">
                <a className="adm-btn" href={`mailto:${r.email}?subject=Re: your enquiry to Brukaan`}>Reply by email</a>
                {r.phone && <a className="adm-btn" href={`https://wa.me/${String(r.phone).replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>}
                {r.phone && <a className="adm-btn" href={`tel:${r.phone}`}>Call</a>}
                <select value={r.status} onChange={(e) => setStatus(r.id, e.target.value)}>{['new', 'contacted', 'closed'].map((s) => <option key={s}>{s}</option>)}</select>
                <button className="adm-btn danger" onClick={() => del(r.id)}>Delete</button>
              </div>
            </div>
          )}
        </div>
      ))}
    </>
  )
}

/* --------------------------- Generic resource CRUD --------------------------- */
function Resource({ name, notify, uploads }: { name: string; notify: (m: string, b?: boolean) => void; uploads: boolean }) {
  const def = resources[name]
  const [rows, setRows] = useState<Row[] | null>(null)
  const [editing, setEditing] = useState<Row | 'new' | null>(null)
  const load = useCallback(() => { api(`/api/admin/${name}`).then((d) => setRows(d.rows)).catch((e) => notify(e.message, true)) }, [name, notify])
  useEffect(load, [load])
  const cols = def.fields.filter((f) => f.showInList)

  async function toggle(r: Row) {
    try { await api(`/api/admin/${name}/${r.id}`, { method: 'PATCH', body: JSON.stringify({ published: !r.published }) }); load() } catch (e: any) { notify(e.message, true) }
  }
  if (!rows) return <p className="adm-muted">Loading…</p>
  return (
    <>
      <div className="adm-head"><h1>{def.label}</h1>{def.canCreate && <button className="adm-btn primary" onClick={() => setEditing('new')}>+ Add {def.singular}</button>}</div>
      {rows.length === 0 && <div className="adm-card"><p className="adm-muted">No {def.label.toLowerCase()} yet. Use “Add” above, or import the defaults from the Dashboard.</p></div>}
      {rows.length > 0 && (
        <table className="adm-table">
          <thead><tr>{cols.map((c) => <th key={c.name}>{c.label}</th>)}<th /></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.id}>
              {cols.map((c) => <td key={c.name}>{c.type === 'boolean' ? <button className={`pill ${r[c.name] ? 'on' : 'off'}`} onClick={() => toggle(r)}>{r[c.name] ? 'Live' : 'Hidden'}</button> : String(r[c.name] ?? '—')}</td>)}
              <td className="adm-actions"><button className="adm-btn sm" onClick={() => setEditing(r)}>Edit</button></td>
            </tr>))}</tbody>
        </table>
      )}
      {editing && <Editor def={def} name={name} row={editing === 'new' ? null : editing} uploads={uploads} notify={notify} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load() }} />}
    </>
  )
}

function Editor({ def, name, row, uploads, notify, onClose, onSaved }: { def: ResourceDef; name: string; row: Row | null; uploads: boolean; notify: (m: string, b?: boolean) => void; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState<Row>(() => {
    if (row) return { ...row }
    const d: Row = {}; def.fields.forEach((f) => { d[f.name] = f.type === 'boolean' ? true : f.type === 'images' ? [] : f.type === 'select' ? f.options?.[0]?.value ?? '' : '' }); return d
  })
  const [busy, setBusy] = useState(false)
  const set = (k: string, val: unknown) => setV((p) => ({ ...p, [k]: val }))

  async function save() {
    setBusy(true)
    try {
      await api(row ? `/api/admin/${name}/${row.id}` : `/api/admin/${name}`, { method: row ? 'PATCH' : 'POST', body: JSON.stringify(v) })
      notify('Saved'); onSaved()
    } catch (e: any) { notify(e.message, true); setBusy(false) }
  }
  async function del() {
    if (!row || !confirm(`Delete this ${def.singular}? This cannot be undone.`)) return
    try { await api(`/api/admin/${name}/${row.id}`, { method: 'DELETE' }); notify('Deleted'); onSaved() } catch (e: any) { notify(e.message, true) }
  }
  return (
    <div className="adm-modal" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="adm-drawer">
        <div className="adm-head"><h2>{row ? `Edit ${def.singular}` : `New ${def.singular}`}</h2><button className="adm-btn sm" onClick={onClose}>Close</button></div>
        <div className="adm-form">{def.fields.filter((f) => !f.readOnly).map((f) => <FieldInput key={f.name} f={f} value={v[f.name]} onChange={(x) => set(f.name, x)} uploads={uploads} notify={notify} />)}</div>
        <div className="adm-row sticky">
          <button className="adm-btn primary" onClick={save} disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
          {row && def.canDelete && <button className="adm-btn danger" onClick={del}>Delete</button>}
        </div>
      </div>
    </div>
  )
}

function FieldInput({ f, value, onChange, uploads, notify }: { f: Field; value: any; onChange: (v: any) => void; uploads: boolean; notify: (m: string, b?: boolean) => void }) {
  const [busy, setBusy] = useState(false)
  async function up(files: FileList | null, multi: boolean) {
    if (!files?.length) return
    if (!uploads) return notify('Uploads are not enabled yet — paste an image URL instead (see Dashboard checklist).', true)
    setBusy(true)
    try {
      const urls: string[] = []
      for (const file of Array.from(files)) { const p = await prepareImage(file); urls.push(await uploadBlob(p.full, file.name)) }
      onChange(multi ? [...(value || []), ...urls] : urls[0])
    } catch (e: any) { notify(e.message, true) } finally { setBusy(false) }
  }
  const label = <span className="lbl">{f.label}{f.required ? ' *' : ''}</span>
  const help = f.help && <small>{f.help}</small>
  switch (f.type) {
    case 'textarea': return <label>{label}<textarea rows={4} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />{help}</label>
    case 'select': return <label>{label}<select value={value ?? ''} onChange={(e) => onChange(e.target.value)}>{f.options!.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>{help}</label>
    case 'boolean': return <label className="chk"><input type="checkbox" checked={!!value} onChange={(e) => onChange(e.target.checked)} />{label}</label>
    case 'number': return <label>{label}<input type="number" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />{help}</label>
    case 'image': return (
      <div className="img-field">{label}
        {value && <img src={value} alt="" />}
        <input placeholder="Paste image URL or upload →" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
        <label className="adm-btn sm">{busy ? 'Uploading…' : 'Upload'}<input type="file" accept="image/*" hidden onChange={(e) => up(e.target.files, false)} /></label>
      </div>)
    case 'images': return (
      <div className="img-field">{label}
        <div className="thumbs">{(value || []).map((u: string, i: number) => <div key={u + i}><img src={u} alt="" /><button type="button" onClick={() => onChange(value.filter((_: string, j: number) => j !== i))} aria-label="Remove">×</button></div>)}</div>
        <div className="adm-row"><label className="adm-btn sm">{busy ? 'Uploading…' : 'Upload images'}<input type="file" accept="image/*" multiple hidden onChange={(e) => up(e.target.files, true)} /></label>
          <button type="button" className="adm-btn sm" onClick={() => { const u = prompt('Image URL'); if (u) onChange([...(value || []), u]) }}>Add by URL</button></div>
        {help}</div>)
    default: return <label>{label}<input value={value ?? ''} onChange={(e) => onChange(e.target.value)} />{help}</label>
  }
}

/* ------------------------------ Gallery manager ------------------------------ */
function MediaManager({ notify, uploads }: { notify: (m: string, b?: boolean) => void; uploads: boolean }) {
  const [rows, setRows] = useState<Row[] | null>(null)
  const [cat, setCat] = useState('all')
  const [upCat, setUpCat] = useState('exteriors')
  const [progress, setProgress] = useState<string>('')
  const [editing, setEditing] = useState<Row | null>(null)
  const load = useCallback(() => { api('/api/admin/media').then((d) => setRows(d.rows)).catch((e) => notify(e.message, true)) }, [notify])
  useEffect(load, [load])
  const shown = useMemo(() => (rows ?? []).filter((r) => cat === 'all' || r.category === cat), [rows, cat])

  async function bulk(files: FileList | null) {
    if (!files?.length) return
    if (!uploads) return notify('Uploads are not enabled yet. Add BLOB_READ_WRITE_TOKEN in your hosting settings, or add images by URL.', true)
    const list = Array.from(files); let ok = 0
    for (let i = 0; i < list.length; i++) {
      setProgress(`Uploading ${i + 1} of ${list.length}…`)
      try {
        const p = await prepareImage(list[i])
        const [url, thumbUrl] = [await uploadBlob(p.full, list[i].name), await uploadBlob(p.thumb, `thumb-${list[i].name}`)]
        const title = list[i].name.replace(/\.\w+$/, '').replace(/[-_]+/g, ' ').slice(0, 80) || 'Untitled'
        await api('/api/admin/media', { method: 'POST', body: JSON.stringify({ title, category: upCat, url, thumbUrl, width: p.width, height: p.height, sortOrder: -Date.now() % 100000, published: true }) })
        ok++
      } catch (e: any) { notify(`${list[i].name}: ${e.message}`, true) }
    }
    setProgress(''); if (ok) notify(`${ok} image${ok > 1 ? 's' : ''} added`); load()
  }
  async function patch(r: Row, body: Row) { try { await api(`/api/admin/media/${r.id}`, { method: 'PATCH', body: JSON.stringify(body) }); load() } catch (e: any) { notify(e.message, true) } }

  if (!rows) return <p className="adm-muted">Loading…</p>
  return (
    <>
      <div className="adm-head"><h1>Gallery</h1>
        <div className="adm-row">
          <select value={upCat} onChange={(e) => setUpCat(e.target.value)} aria-label="Category for new uploads">{Object.entries(galleryCategories).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
          <label className="adm-btn primary">{progress || '+ Upload images'}<input type="file" accept="image/*" multiple hidden onChange={(e) => { bulk(e.target.files); e.target.value = '' }} /></label>
          <button className="adm-btn" onClick={() => setEditing({ __new: true, category: upCat, published: true, title: '', url: '' })}>Add by URL</button>
        </div></div>
      <div className="adm-tabs"><button className={cat === 'all' ? 'on' : ''} onClick={() => setCat('all')}>All ({rows.length})</button>
        {Object.entries(galleryCategories).map(([k, l]) => <button key={k} className={cat === k ? 'on' : ''} onClick={() => setCat(k)}>{l} ({rows.filter((r) => r.category === k).length})</button>)}</div>
      {rows.length === 0 && <div className="adm-card"><p className="adm-muted">The gallery is empty. Upload images, or import the 68 default photos from the Dashboard.</p></div>}
      <div className="adm-grid">
        {shown.map((r) => (
          <figure key={r.id} className={r.published ? '' : 'hidden'}>
            <img src={r.thumbUrl || r.url} alt={r.title} loading="lazy" />
            <figcaption><span title={r.title}>{r.title}</span>
              <span><button onClick={() => patch(r, { published: !r.published })}>{r.published ? 'Hide' : 'Show'}</button><button onClick={() => setEditing(r)}>Edit</button></span></figcaption>
          </figure>))}
      </div>
      {editing && <Editor def={resources.media} name="media" row={editing.__new ? null : editing} uploads={uploads} notify={notify} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load() }} />}
    </>
  )
}

/* -------------------------------- Settings -------------------------------- */
function SettingsForm({ notify }: { notify: (m: string, b?: boolean) => void }) {
  const [v, setV] = useState<Row | null>(null)
  const [busy, setBusy] = useState(false)
  useEffect(() => { api('/api/admin/settings').then((d) => setV(d.settings)).catch((e) => notify(e.message, true)) }, [notify])
  if (!v) return <p className="adm-muted">Loading…</p>
  async function save() {
    setBusy(true)
    try { await api('/api/admin/settings', { method: 'PUT', body: JSON.stringify(v) }); notify('Settings saved — the website will update within a minute.') } catch (e: any) { notify(e.message, true) } finally { setBusy(false) }
  }
  return (
    <>
      <div className="adm-head"><h1>Studio settings</h1><button className="adm-btn primary" onClick={save} disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button></div>
      <div className="adm-form wide">{settingsFields.map((f) => <FieldInput key={f.name} f={f} value={v[f.name]} onChange={(x) => setV({ ...v, [f.name]: x })} uploads={false} notify={notify} />)}</div>
    </>
  )
}
